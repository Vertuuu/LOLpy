from setuptools import setup, find_packages


setup(
    name="LOLpy",
    version="0.0.1",
    packages=find_packages(),
    description= "A small LOL project",
    
)